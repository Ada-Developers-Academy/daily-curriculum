## HTML & CSS Resources

#### HTML

- [HTMLDog.com](http://htmldog.com/guides/html)
- [W3](http://www.w3.org/html/)
- [Dive into HTML5](http://diveintohtml5.info)

### CSS

- [HTMLDog.com](http://htmldog.com/guides/css/)
- [CSS3](http://www.css3.info)


#### Recommended Reading

- [HTML & CSS Book](http://www.htmlandcssbook.com)
- [Building Your First Webpage]http://learn.shayhowe.com/html-css/building-your-first-web-page/
