# DOM part 2

This lesson we're reach even further into the DOM


### Review - Create Element, put in place
* doc.createElement
* el.appendChild

### Create Object, add method to its prototype
* `var Foobarer = function(){};`
* `Foobarer.prototype.foobar = function(){};`


### Create event listener, attach to element, callback should be prototype method


### Create custom event, dispatch event.
