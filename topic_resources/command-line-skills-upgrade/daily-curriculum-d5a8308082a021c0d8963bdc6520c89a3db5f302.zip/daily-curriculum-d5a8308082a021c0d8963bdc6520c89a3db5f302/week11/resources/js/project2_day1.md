# Day 1, Project 2: Create a to do object, with the following properties:

- a task (a string) - a description of the thing to do
- who (a string) - the name of a person to do it
- done (a boolean) - is the task done or not?
- getDone (a method) - get the value of done, use "this" in the body of the method.
- setDone (a method) - set the value of done, use "this" in the body of the method.

## SILVER: Create 2 or 3 of these to do objects.

## PLATINUM: Create an array of to do objects.


