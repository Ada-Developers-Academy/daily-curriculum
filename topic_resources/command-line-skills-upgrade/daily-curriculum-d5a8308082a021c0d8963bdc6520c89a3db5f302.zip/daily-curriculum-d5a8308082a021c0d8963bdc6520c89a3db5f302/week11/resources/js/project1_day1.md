# Day 1, Project 1: Goal: Find the biggest number in the array

- Initialize a variable to keep track of the biggest item so far.
- Use a for loop to look at each item in the array.
- If the current item is bigger than the biggest one so far, then make the current item the biggest one.
- After we get to the end of the array, return the variable with the biggest item.

```javascript
var arrayOfNums = [2, 7, 7, 3, 9, 0, 1, 6, 8, 3, 8, 4, 7, 9];

function getBiggest(array) {

// your code goes here!!

}

//
// pass an array to getBiggest;
// get a return value that is the biggest number in the array
//
var biggest = getBiggest(arrayOfNums);
console.log("The biggest is: ", biggest);
```

