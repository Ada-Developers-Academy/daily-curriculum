# Syntax, Floating Point Numbers, Primitives

This lesson will focus on JavaScript's Syntax, Primitive types that are
native to the language, and the crazy math problems that floating point numbers introduce


### Syntax
* Braces
  * Sometimes necessary
* Semi-colons
  * ASI
* if, else if, else
* while
* new Foo
* Parens


### Primitives
* Objects
* Functions
* Arrays
* Numbers
* Strings
* Booleans


### Floating point... huh?
* 0.1 + 0.2 === 0.30000000000000004
* WTF?
* Good ol 1s and 0s
* parseInt/parseFloat/toFixed

