Capstone Presentation Groups
-----------

## Group 1

- Rebecca Mark Speechable
- Bri Dotson | An upgrade to the teleporter at the greenwood space travel supply co.
- Rachel Adler | Rdio Karakoke
- Calla Patel Gramble

## Group 2

- Holly Leary | Wat do
- Katie Bosch | Seattle a2b
- Stephanie Kwak | Project Dispatch
- Lily Pace & Cate Uselton | Wandr
- Rachelle Keblitis | Hangry Noms

## Group 3

- Bonnie Kwong | Ada Stock Picker
- Kamilah Jenkins | Visualizing Disparity
- Stephanie Pi | Visualizing Police Brutality
- Crystal Pererra | Critical Lens
- Kate Fulton & Richa Arora | Web app for NWIRP data

## Group 4

- Kristin McCabe | Seattle Park Finder
- Allie Sterling | Eagle Readers
- Kristina Hjertberg & Kat Patke | Shut up Seattle
- Brenda Pragastis & Linnea Daimer | Disease Tracks
