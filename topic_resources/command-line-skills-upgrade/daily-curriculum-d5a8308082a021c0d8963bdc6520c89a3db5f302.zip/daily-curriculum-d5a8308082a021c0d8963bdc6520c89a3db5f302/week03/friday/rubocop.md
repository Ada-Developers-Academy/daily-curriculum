!SLIDE text-size-80 title-and-content transition=fade

Rubocop
=======

## Role models are important. *-- Officer Alex J. Murphy / RoboCop*

<center><img src=robocop.jpg width=600></center>


!SLIDE title-and-content transition=fade

Rubocop
=======

RuboCop is a Ruby static code analyzer. Out of the box it will enforce many of the guidelines outlined in the community Ruby Style Guide.

https://github.com/bbatsov/rubocop/

Community Style Guide:<br>
https://github.com/bbatsov/ruby-style-guide


!SLIDE title-and-content transition=fade

Rubocop
=======

```
$ gem install rubocop
```

```
$ rubocop
```
