pandoc -t slidy -s 'provisioning-and-deploying-to-a-vps.md' -o lecture.html
