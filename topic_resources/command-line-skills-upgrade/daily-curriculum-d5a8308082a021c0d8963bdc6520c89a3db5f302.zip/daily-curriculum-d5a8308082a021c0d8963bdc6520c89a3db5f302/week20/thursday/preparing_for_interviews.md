Preparing for Interviews
-------------------
Tomorrow you'll be meeting with hiring managers from Marchex (Ada Conference Room), Zillow (Skype Conference Room - 15th floor lobby), and LiquidPlanner (Surface Conference Room - 15th floor lobby). Interviews are 15 minutes each, with a 5 minute break between sessions. 

## To Bring
- printed copies of your resume
- notepad to take company notes
- your laptop with code sample and favorite app pulled up
- interview-ready clothes (yogi's chocie)

## Logistics
- it's a super tight schedule; please be near the conference room a couple of minutes early
- conference room wifi: SeaGuest pass: ChamberGuest