# Holiday Break Project

Create an application during the holiday break. The app can be anything that you want! Here are some examples to get creative juices flowing:

- http://thissocks.herokuapp.com/ (Blake's C1 project)
- http://bksydg.com/
- http://whatcoloristheempirestatebuilding.com/
- http://www.shibui.me/web/scroll/index.html (pretty intense, but you get the idea)
- http://stewd.io/pong/ (again intense)
- http://www.rikeripsum.com
