SOA Implementation
------------------
