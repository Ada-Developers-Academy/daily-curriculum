Rembember when pairing
----------------------

- Listen
- Give partner the oppurtunity to work things through.
- Both people should have the time to explore
- Communicate
- Patience
