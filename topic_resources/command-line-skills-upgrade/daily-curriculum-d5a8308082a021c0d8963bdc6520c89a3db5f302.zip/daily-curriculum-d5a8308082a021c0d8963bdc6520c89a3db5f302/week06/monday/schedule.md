!SLIDE text-size-90 title-and-content transition=fade

Monday, December 2
==================

| Time              | Topic                                    |
|:-----------------:|:----------------------------------------:|
| **9:05 - 9:15**   | Standup                                  |
| **9:15 - 10:45**  | Presentations                            |
| **10:45 - 11:00** | Break                                    |
| **11:00 - 12:00** | [Introduction to Rails](monday/rails.md) |
| **12:00 - 1:30*** | Project Time - [Ada Cooks](ada_cooks.md) |
| **1:30 - 2:30**   | [ActiveRecord](monday/active_record.md)  |
| **2:30 - 5:00**   | Project Time - [Ada Cooks](ada_cooks.md) |

\* Take an hour lunch at any time


