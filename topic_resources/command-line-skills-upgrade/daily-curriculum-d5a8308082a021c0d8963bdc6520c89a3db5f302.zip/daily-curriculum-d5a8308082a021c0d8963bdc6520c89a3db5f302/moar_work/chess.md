# Chess

Create a Command Line Chess game.

- Object Oriented (this is a great one for inheritance)
- Two players (each person will have to pass the keyboard)
- Obey the rules of [chess](http://en.wikipedia.org/wiki/Chess).
- Re-Draw an ASCII-board for each turn.
- Implement a game timer for each player
