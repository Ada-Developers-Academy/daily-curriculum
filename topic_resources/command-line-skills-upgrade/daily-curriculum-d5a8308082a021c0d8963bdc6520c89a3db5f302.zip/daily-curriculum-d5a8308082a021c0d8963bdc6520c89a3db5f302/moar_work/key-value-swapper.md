# Key Value Swapper

Make a method that takes a hash as an argument and swaps each key with it's value.

```ruby
a = {name: "Wabi", species: "Cat"}
swap(a)
# => {"Wabi" => :name, "Cat" => :species}
```
