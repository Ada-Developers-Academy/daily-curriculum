# Calculator

Create a Calculator class which takes two integers in the constructor. Implement `add`, `subtract`, `multiply`, and `divide` methods.

Silver
------
Allow a list of number instead of just two integers to apply the methods to.
