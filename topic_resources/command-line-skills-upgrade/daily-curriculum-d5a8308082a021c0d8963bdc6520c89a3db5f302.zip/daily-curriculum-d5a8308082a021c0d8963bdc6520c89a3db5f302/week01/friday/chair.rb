class Chair
  def name
    "Vilgot"
  end

  def weight_in_lbs
    29
  end

  def type
    "Swivel"
  end

  def color
    "Black"
  end

  def max_height
    23.625
  end
end
