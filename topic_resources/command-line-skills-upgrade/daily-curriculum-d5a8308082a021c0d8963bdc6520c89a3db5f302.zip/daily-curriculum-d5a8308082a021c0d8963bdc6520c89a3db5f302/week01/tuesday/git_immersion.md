!SLIDE title-and-content transition=fade

Git Immersion Lab
=================

http://gitimmersion.com

Work through as much of the Git Immersion lessons as you can today. If you don't get through all of it today, try to get through to at least lesson 29, and finish the rest by Thursday morning.