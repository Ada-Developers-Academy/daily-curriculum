# Notes

Change git commit message editor

```
git config --global core.editor "subl -w"
```