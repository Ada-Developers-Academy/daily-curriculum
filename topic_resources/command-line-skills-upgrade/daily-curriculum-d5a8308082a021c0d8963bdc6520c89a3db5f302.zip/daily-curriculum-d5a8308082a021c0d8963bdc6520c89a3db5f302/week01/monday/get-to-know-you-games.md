!SLIDE transition=fade

Categories!


Good or bad news?
arms crossed - which is on top?
Favorite movie genre?
hand clasped - thumb on top?
hot beverage?
Cable TV?
favorite pet?
type of shoes
season of the year you were born in?
toiletpaper - over or under?
which side of the bed do you get out of?
mode of transport taken today