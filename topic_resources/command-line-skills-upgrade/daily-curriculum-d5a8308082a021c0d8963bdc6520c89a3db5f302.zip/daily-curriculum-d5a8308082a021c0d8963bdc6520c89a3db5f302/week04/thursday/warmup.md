!SLIDE text-size-80 title-and-content transition=fade

Hamming Distance
================
Implement a Hamming class that passes the spec provided. Read the *README.md* and run the spec by running ```rspec``` from inside *daily_curriculum/examples/week4/hamming* 

The spec should all fail, complaining about 7 errors - this is expected! No need to be alarmed or overwhelmed. Read through the spec file (in *spec/lib/hamming_spec.rb*) to get a sense of what it expects our Hamming class to do, and address the failing specs one at a time.

