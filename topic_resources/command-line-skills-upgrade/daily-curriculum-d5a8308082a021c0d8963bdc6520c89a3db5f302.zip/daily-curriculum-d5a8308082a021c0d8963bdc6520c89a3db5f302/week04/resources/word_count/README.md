Write a Phrase class that counts the number of times a word is used in a given string, keeping count of each occurrence in a hash.

For example for the input `"olly olly in come free"`

```ruby
{ 'olly' => 2, 'in' => 1, 'come' => 1, 'free' => 1 }
```

If you finish early, help someone else! Mention that you're done and free to help in Campfire, put your name up on the white board so if anyone in the class could use a hand they'll know they can talk to you, or take a few minutes and look at someone else's solution.
