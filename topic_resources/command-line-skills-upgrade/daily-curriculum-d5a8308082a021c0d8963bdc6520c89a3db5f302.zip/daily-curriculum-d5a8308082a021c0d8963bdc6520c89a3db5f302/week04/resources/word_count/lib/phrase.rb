# Implement a Phrase Class here:
#
class Phrase
end
