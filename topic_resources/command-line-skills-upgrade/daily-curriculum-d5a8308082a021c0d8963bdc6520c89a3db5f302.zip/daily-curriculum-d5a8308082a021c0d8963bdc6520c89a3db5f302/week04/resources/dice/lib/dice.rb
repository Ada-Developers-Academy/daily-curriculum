# Implement a Dice Class here:
#
class Dice
end