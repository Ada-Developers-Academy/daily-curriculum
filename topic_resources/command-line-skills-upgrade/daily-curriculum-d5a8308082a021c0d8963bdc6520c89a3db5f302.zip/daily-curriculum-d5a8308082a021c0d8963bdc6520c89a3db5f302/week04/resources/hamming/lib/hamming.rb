# Implement a Hamming Class here:
#
class Hamming
end
