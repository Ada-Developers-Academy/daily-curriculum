!SLIDE text-size-90 transition=fade

SQLite
===

## Deleting a record

```sql
sqlite> DELETE FROM posts WHERE id = 1;
sqlite> select * from posts;
sqlite>
```

## Both INSERT and UPDATE require more caution than usual. ALWAYS be sure you're specifying your records with care!

