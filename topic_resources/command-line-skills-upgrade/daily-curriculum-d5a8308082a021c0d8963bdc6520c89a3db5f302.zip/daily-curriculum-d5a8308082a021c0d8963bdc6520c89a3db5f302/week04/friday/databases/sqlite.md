!SLIDE text-size-90 transition=fade

SQLite
===

## Tiny relational database engine

http://sqlite.org/

```bash
$ sqlite3
SQLite version 3.8.1 2013-10-17 12:57:35
Enter ".help" for instructions
Enter SQL statements terminated with a ";"
sqlite> select current_date;
2013-11-22
sqlite>
```
