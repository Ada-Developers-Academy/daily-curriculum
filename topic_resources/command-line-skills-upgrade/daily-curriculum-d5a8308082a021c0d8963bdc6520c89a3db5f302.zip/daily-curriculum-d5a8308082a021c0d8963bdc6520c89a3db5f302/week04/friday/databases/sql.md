!SLIDE text-size-90 transition=fade

SQL (Structured Query Language)
===

## The language of relational databases

## DDL: Data Definition Language
### Create, Drop, Alter...
## DML: Data Manipulation Language
### Select, Insert, Update, Delete...
## DCL, TCL...
