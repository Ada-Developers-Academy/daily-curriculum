!SLIDE text-size-90 transition=fade

What Even Is A Database?
===

## The thing you keep your data in.

Sadly, yes, this includes Excel. (JOKE)

## Several popular paradigms:

### Relational
### Document
### Key-Value
### Object
### Graph, etc.
