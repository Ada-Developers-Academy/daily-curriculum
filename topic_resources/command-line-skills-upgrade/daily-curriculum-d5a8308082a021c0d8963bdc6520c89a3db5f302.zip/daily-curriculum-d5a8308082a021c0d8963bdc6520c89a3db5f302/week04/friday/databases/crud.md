!SLIDE text-size-90 transition=fade

CRUD
===

## Create, Read (Select), Update, Delete

Sound familiar?

## POST, GET, PATCH, DELETE

---

## That's our cue! Time to do ToDo!

