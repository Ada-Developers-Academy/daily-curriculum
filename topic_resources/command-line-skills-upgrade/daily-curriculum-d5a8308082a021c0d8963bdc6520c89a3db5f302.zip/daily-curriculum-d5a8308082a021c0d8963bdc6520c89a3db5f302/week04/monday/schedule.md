!SLIDE text-size-90 title-and-content transition=fade

Monday, November 18
==================

| Time              | Topic               |
|:-----------------:|:--------------------|
| **9:15 - 9:30**   | Standup             |
| **9:30 - 9:50**   | Week 3 Recap        |
| **9:50 - 11:30**  | Sam Livingston-Gray |
| **11:30 - 2:30*** | Project Time        |
| **2:30 - 3:30**   | Sam Livingston-Gray |
| **3:30 - 5:00**   | Project Time        |

\* Take an hour lunch at any time


