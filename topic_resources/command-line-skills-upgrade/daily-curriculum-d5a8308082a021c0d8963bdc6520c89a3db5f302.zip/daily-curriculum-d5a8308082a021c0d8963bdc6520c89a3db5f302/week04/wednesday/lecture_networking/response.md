!SLIDE text-size-90 transition=fade

Server
===

 * Start, Headers, Body
 * Status Codes:
   1xx, 2xx, 3xx, 4xx, 5xx

```
HTTP/1.1 204 OK
Server: ADA Server 0.0.1
Content-Type: text/html; charset=UTF-8
```

