!SLIDE text-size-90 transition=fade

Rack
===

 * Many Ruby Web Servers, One Interface
 * Middleware

