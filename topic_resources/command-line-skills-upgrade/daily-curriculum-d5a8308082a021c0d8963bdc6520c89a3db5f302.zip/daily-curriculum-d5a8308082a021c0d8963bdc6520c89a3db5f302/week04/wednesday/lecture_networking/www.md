!SLIDE text-size-90 transition=fade

World Wide Web
===

 * World Wide Web Consortium (W3C)
 * Client/Server
 * Content Types
 * Hypertext

