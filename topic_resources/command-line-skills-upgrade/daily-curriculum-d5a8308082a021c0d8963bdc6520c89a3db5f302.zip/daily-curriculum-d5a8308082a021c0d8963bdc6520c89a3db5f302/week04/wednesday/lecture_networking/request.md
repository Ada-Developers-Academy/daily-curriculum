!SLIDE text-size-90 transition=fade

Client, User Agent, Browser
===

 * Start, Headers, Body
 * HTTP Methods:
   GET, POST, PUT, DELETE, PATCH, OPTIONS, HEAD, TRACE, CONNECT

```
GET / HTTP/1.1
Host: 0.0.0.0:4567
User-Agent: ADAbot
Accept: text/html
```

