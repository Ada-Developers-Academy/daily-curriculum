!SLIDE text-size-90 title-and-content transition=fade

Wednesday, November 20
==================

| Time               | Topic                             |
|:------------------:|:---------------------------------:|
| **9:00 - 9:45**    | Morning Warmup - Dice             |
| **9:45 - 10:00**   | Stand Up                          |
| **10:00 - 10:30**  | Intro to HTTP, Clients, & Servers |
| **10:30 - 12:00*** | Project Time                      |
| **1:30 - 2:30**    | Status Codes, DSLs, Routes        |
| **2:30 - 3:00**    | Quiz                              |
| **3:00 - 5:00**    | Project time                      |

\* Take an hour lunch at any time


