ListItem2 = Struct.new(:data, :next)
