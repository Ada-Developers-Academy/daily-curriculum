Schedule for Classroom Instruction
==================================

Week 01 - Sept 2: Bash, Git, Ruby

Week 02 - Sept 8: Ruby II

Week 03 - Sept 15: Ruby III

Week 04 - Sept 22: Testing, Sinatra, HTTP, DOM & HTML

Week 05 - Sept 29: HTML & CSS

Week 06 - Oct 6: Intro to Rails

Week 07 - Oct 13: Rails II

Week 08 - Oct 20: Adv Ruby & CS Fundamentals

Week 09 - Oct 27: Rails III, Intro to Agile

Week 11 - Nov 3: Midterm Project

Week 10 - Nov 10: Intro to Javascript

Week 12 - Nov 17: Special Topics & Midterm Project

Week 13 - Nov 24: Midterm Project Presentations; Rails Individual Project

Week 14 - Dec 1: 2 week pairing Rails Project

Week 15 - Dec 8: 2 week pairing Rails Project

Week 16 - Dec 15: Group SOA Rails Project

** Holiday Break **

Week 17 - Jan 5:  Group SOA Rails Project

Week 18 - Jan 12: Pair JS Framework Project

Week 19 - Jan 19: Pair JS Framework Project

Week 20 - Jan 26: Individual Student-Defined Rails Project

Week 21 - Feb 2: Final Rails Project

Week 22 - Feb 9: Final Rails Project

Week 23 - Feb 16: Final Rails Project

Week 24 - Feb 23: Final Rails Project Presentations


Books
=====
[Learn to Program](http://pine.fm/LearnToProgram/) by Chris Pine

[Beginning Ruby](http://beginningruby.org/) by Peter Cooper

[Sinatra Up and Running](http://shop.oreilly.com/product/0636920019664.do) by Alan Harris & Konstantin Haase

[Ruby on Rails Tutorial](http://ruby.railstutorial.org/) by Michael Hartl

[Computer Science Programming Basics in Ruby](http://shop.oreilly.com/product/0636920028192.do) by Ophir Frieder, Gideon Frieder, David Grossman
