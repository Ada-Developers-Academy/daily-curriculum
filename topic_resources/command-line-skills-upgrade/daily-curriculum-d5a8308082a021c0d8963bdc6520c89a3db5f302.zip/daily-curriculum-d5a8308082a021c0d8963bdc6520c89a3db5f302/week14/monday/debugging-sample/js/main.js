var foo = function (x) {
  var y = x;
  console.log(x);

  return x;
};



