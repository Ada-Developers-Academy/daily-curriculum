# License

[Ada Developers Academy](http://adadevelopersacademy.org)'s Curriculum is licensed [Creative Commons Attribution-ShareAlike 4.0](http://creativecommons.org/licenses/by-sa/4.0/).
![Creative Commons License](http://i.creativecommons.org/l/by-sa/4.0/80x15.png)
