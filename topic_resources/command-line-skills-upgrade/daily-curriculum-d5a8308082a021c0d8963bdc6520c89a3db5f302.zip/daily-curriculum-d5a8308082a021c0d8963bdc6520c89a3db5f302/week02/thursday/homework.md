!SLIDE text-size-70 title-and-content transition=fade

Homework
========

+ Check Canvas for the latest!
+ Write down the 3 stand up questions
+ Homework repo (details TBA)

