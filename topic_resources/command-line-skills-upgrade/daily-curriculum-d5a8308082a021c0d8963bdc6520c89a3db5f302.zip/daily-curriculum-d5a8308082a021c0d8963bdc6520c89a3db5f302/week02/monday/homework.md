!SLIDE text-size-70 title-and-content transition=fade

Homework
========
+ 8 minute video on Object Oriented Programming: http://www.youtube.com/watch?v=c5kfCH50wl0
+ Read Chapter 13 of Learning To Program
  + Ignore 13.1
  + Work through the Die examples in 13.2 and 13.3
  + Read through, but don't type up, the Dragon class from section 13.5
  + Don't do the A Few Things To Try at the end of the chapter - we'll do those in class on Tuesday
+ review "object-orientation.md" slides from last Thursday
+ Write down the 3 stand up questions
+ Homework repo (details TBA)
