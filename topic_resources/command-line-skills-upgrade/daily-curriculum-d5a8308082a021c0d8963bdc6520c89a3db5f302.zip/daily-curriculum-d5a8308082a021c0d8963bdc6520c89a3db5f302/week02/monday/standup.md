!SLIDE text-size-80 title-and-content transition=fade

Stand Up!
=========

+ break into groups of 4
  + try to group with new people every day!
+ take turns sharing your answers to The 3 Questions
  + What did you learn yesterday?
  + What from yesterday do you want to know more about?
  + What from yesterday stumped you?
