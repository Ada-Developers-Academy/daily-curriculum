!SLIDE title-and-content transition=fade

Ice Cream Party Planner
=======================

<center>![](http://www.colonlibrary.org/wp-content/uploads/2013/07/party-time-icecream.jpg)</center>

!SLIDE text-size-120 title-and-content transition=fade

Instructions
============

```
daily-curriculum:

examples/week2/ice_cream_party_planner/README.md
```


