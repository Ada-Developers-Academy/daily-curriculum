!SLIDE text-size-80 title-and-content transition=cover

Last Week on Ada...
===================

### Introduction to our tools

+ Basic BASH
+ Intro to git
+ Atom Text

!SLIDE text-size-80 title-and-content transition=cover

Last Week on Ada...
===================

### Introduction to each other

+ Ada Board said hello
+ Categories Game
+ Cupcakes!

!SLIDE text-size-80 title-and-content transition=cover

Last Week on Ada...
===================

### Began to explore Ruby

+ Using IRB
+ Strings and Numbers
+ Loops and Conditionals
+ Arrays and Hashes
+ Methods and Objects

!SLIDE text-size-80 title-and-content transition=cover

Last Week on Ada...
===================

### Building things!

+ RailsBridge
+ Calculator
+ Adventure Game


!SLIDE text-size-80 title-and-content transition=cover

This Week on Ada...
===================

+ Working with dates and times
+ Our first external library ("gem")
+ Objects! Lots of Objects!
+ Methods - public and private
+ Get ready to write some games!
