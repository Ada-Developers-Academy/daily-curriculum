!SLIDE text-size-80 title-and-content transition=fade

Personality Sorting Hat
=======================

Make a new class "SortingHat" in personality_sorting_hat.rb. 

A PSH (Personality Sorting Hat) object answers 'Well you are inquisitive aren't you?' if you ask her a question.

She answers 'Well you are rather loud aren't you?' if you yell at her (ALL CAPS).

She says 'Hello?… Are you there? You are too quiet… Or perhaps you don't exist' if you address her without actually saying anything.

She answers 'Hmmmm…. I don't know… you seem complex.' to anything else.
