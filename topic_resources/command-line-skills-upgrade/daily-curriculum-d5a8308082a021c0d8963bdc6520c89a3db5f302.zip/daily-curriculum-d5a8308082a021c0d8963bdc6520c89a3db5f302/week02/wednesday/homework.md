!SLIDE text-size-70 title-and-content transition=fade

Homework
========
+ Finish seattle.rb response write-up
+ Write up instructions for the 2 methods you shared with your group on Monday and submit to Kerri via http://gist.github.com
+ Practice Hashes! Work through these 2 short online lessons:
  + http://rubymonk.com/learning/books/1-ruby-primer/chapters/10-hashes-in-ruby/lessons/46-introduction-to-ruby-hashes
  + http://rubymonk.com/learning/books/1-ruby-primer/chapters/10-hashes-in-ruby/lessons/47-hashes-in-and-out
+ Write down the 3 stand up questions (seriously - write it down!)
+ Homework repo (details TBA)
