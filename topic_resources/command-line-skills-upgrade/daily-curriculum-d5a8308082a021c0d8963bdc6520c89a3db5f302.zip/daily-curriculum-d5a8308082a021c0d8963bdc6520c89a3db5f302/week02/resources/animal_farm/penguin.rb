require './bird.rb'

class Penguin < Bird
  def fly
    puts "Sorry. I'd rather swim."
  end
end