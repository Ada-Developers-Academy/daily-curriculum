require 'colorize'

class Dog
  def speak
    "Bark bark!"
  end

  def move
    puts "trotting"
  end

  def color
    "White"
  end
end
