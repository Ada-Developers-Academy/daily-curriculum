class Snake
  def speak
    "hiiiiissssss"
  end

  def move
    puts "slithering"
  end

  def color
    "green"
  end
end