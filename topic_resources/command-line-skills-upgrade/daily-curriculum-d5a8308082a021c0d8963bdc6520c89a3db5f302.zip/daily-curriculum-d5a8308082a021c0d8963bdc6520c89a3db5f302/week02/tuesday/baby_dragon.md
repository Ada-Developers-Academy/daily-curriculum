Bronze
------
(See Learning to Program, Chapter 13)

Silver
------
Integrate your baby dragon into a room in your dungeon application.
The player should be asked if they want to do any of the actions  (feed, put to sleep, etc...)
the dragon.
