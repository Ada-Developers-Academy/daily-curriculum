!SLIDE text-size-70 title-and-content transition=fade

Homework
========
+ Write up your thoughts and experience at Seattle.rb
  + Who did you meet?
  + What was interesting?
  + What wasn't interesting?
+ Write down the 3 stand up questions
+ Homework repo (details TBA)
